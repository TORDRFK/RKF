#define MAXLINE 1000 /* maximum input line length */
void copy(char from[], char to[]);
